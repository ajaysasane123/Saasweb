import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: (import.meta as any).env.VITE_FIREBASE_API_KEY || "AIzaSyDfnCex39rnlQrtE3_xg_vE1Ycm2wSO2q4",
  authDomain: (import.meta as any).env.VITE_FIREBASE_AUTH_DOMAIN || "angular-array-459114-v0.firebaseapp.com",
  projectId: (import.meta as any).env.VITE_FIREBASE_PROJECT_ID || "angular-array-459114-v0",
  storageBucket: (import.meta as any).env.VITE_FIREBASE_STORAGE_BUCKET || "angular-array-459114-v0.firebasestorage.app",
  messagingSenderId: (import.meta as any).env.VITE_FIREBASE_MESSAGING_SENDER_ID || "220842519365",
  appId: (import.meta as any).env.VITE_FIREBASE_APP_ID || "1:220842519365:web:d136898ad61715afe3ac2c"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, (import.meta as any).env.VITE_FIREBASE_DATABASE_ID || "ai-studio-b1ca1b76-1f6b-448a-8bd5-b99d4a9015b3");
