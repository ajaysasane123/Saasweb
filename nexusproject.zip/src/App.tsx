/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, Suspense, useMemo } from "react";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Trust } from "./components/Trust";
import { Features } from "./components/Features";
import { Services } from "./components/Services";
import { ProductShowcase } from "./components/ProductShowcase";
import { Benefits } from "./components/Benefits";
import { Pricing } from "./components/Pricing";
import { PaymentSection } from "./components/PaymentSection";
import { Testimonials } from "./components/Testimonials";
import { CTA } from "./components/CTA";
import { Footer } from "./components/Footer";
import { infoPagesList } from "./components/InfoPage";
import { AnimatePresence } from "motion/react";

const InfoPage = React.lazy(() => import('./components/InfoPage').then(module => ({ default: module.InfoPage })));

export default function App() {
  const [currentHash, setCurrentHash] = useState(window.location.hash);

  useEffect(() => {
    const handleHashChange = () => {
      setCurrentHash(window.location.hash);
      
      // If navigating to a landing page section, manually scroll after a tick
      if (window.location.hash && !infoPagesList.includes(window.location.hash)) {
        setTimeout(() => {
          const id = window.location.hash.replace("#", "");
          const el = document.getElementById(id);
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }, 50);
      } else if (!window.location.hash) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const isInfoPage = infoPagesList.includes(currentHash);

  const landingPageContent = useMemo(() => (
    <div key="landing">
      <Hero />
      <Trust />
      <Features />
      <Services />
      <ProductShowcase />
      <Benefits />
      <Pricing />
      <PaymentSection />
      <Testimonials />
      <CTA />
    </div>
  ), []);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-navy-900 transition-colors duration-300 overflow-x-hidden selection:bg-electric selection:text-white">
      <Navbar currentHash={currentHash} />
      <main>
        <AnimatePresence mode="wait">
          {isInfoPage ? (
            <Suspense fallback={<div className="pt-32 pb-24 text-center min-h-[70vh]">Loading...</div>}>
              <InfoPage hash={currentHash} />
            </Suspense>
          ) : landingPageContent}
        </AnimatePresence>
      </main>
      <Footer />
    </div>
  );
}
