import { Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";

export function ThemeToggle({ className = "" }: { className?: string }) {
  const [isDark, setIsDark] = useState(() => {
    // Check local storage or system preference
    if (typeof window !== "undefined") {
      if (typeof localStorage !== "undefined" && localStorage.theme) {
        return localStorage.theme === 'dark';
      }
      return document.documentElement.classList.contains("dark") || 
            window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    return true; // Default to dark for this app
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      root.classList.remove('light');
      localStorage.theme = 'dark';
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
      localStorage.theme = 'light';
    }
  }, [isDark]);

  return (
    <button
      onClick={() => setIsDark(!isDark)}
      className={`p-2.5 rounded-xl border border-gray-200 dark:border-white/10 text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-white dark:hover:bg-white/5 transition-colors ${className}`}
      aria-label="Toggle theme"
    >
      {isDark ? (
        <Sun className="w-5 h-5" />
      ) : (
        <Moon className="w-5 h-5" />
      )}
    </button>
  );
}
