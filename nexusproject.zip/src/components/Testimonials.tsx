import { motion } from "motion/react";

export function Testimonials() {
  const testimonials = [
    {
      quote: "Nexus didn't just speed up our infrastructure, it fundamentally changed how our engineering team ships product. We deploy 5x faster now.",
      author: "Sarah Jenkins",
      role: "CTO at TechPulse",
      avatar: "https://i.pravatar.cc/150?u=sarah"
    },
    {
      quote: "The unified API design is a masterpiece. What used to take us three sprints of integration work is now solved in a single afternoon.",
      author: "David Chen",
      role: "Lead Architect at Horizon",
      avatar: "https://i.pravatar.cc/150?u=david"
    },
    {
      quote: "Security and compliance were our biggest hurdles. Nexus provided out-of-the-box SOC2 compliance that saved us months of audit prep.",
      author: "Elena Rodriguez",
      role: "VP Engineering at Quantum Finance",
      avatar: "https://i.pravatar.cc/150?u=elena"
    }
  ];

  return (
    <section id="customers" className="py-24 lg:py-32 bg-gray-50/50 dark:bg-white/[0.01] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="mb-16 md:text-center">
          <h2 className="font-display text-gray-900 dark:text-white text-3xl md:text-4xl font-bold tracking-tight">
            Loved by engineering leaders
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 rounded-2xl glassmorphism border-gray-200 dark:border-white/5 bg-white/50 dark:bg-transparent flex flex-col justify-between hover:bg-white dark:hover:bg-white/[0.04] shadow-sm hover:shadow-md transition-all duration-300"
            >
              {/* Fake quotes icon */}
              <div className="text-electric dark:text-electric opacity-50 mb-6">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M14.017 18L14.017 10.609C14.017 4.905 17.748 1.039 23 0L23.995 2.151C21.563 3.068 20 5.789 20 8H24V18H14.017ZM0 18V10.609C0 4.905 3.748 1.038 9 0L9.996 2.151C7.563 3.068 6 5.789 6 8H9.983L9.983 18L0 18Z" />
                </svg>
              </div>
              
              <p className="text-gray-700 dark:text-gray-300 mb-8 leading-relaxed text-lg">"{t.quote}"</p>
              
              <div className="flex items-center gap-4">
                <img src={t.avatar} alt={t.author} className="w-12 h-12 rounded-full ring-2 ring-gray-200 dark:ring-white/10" />
                <div>
                  <div className="font-medium text-gray-900 dark:text-white">{t.author}</div>
                  <div className="text-sm text-gray-500">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
