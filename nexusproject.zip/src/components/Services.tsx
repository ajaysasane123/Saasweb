import { motion } from "motion/react";
import { Cloud, Shield, Database, Code } from "lucide-react";

export function Services() {
  const services = [
    {
      id: "service-migration",
      title: "Cloud Migration & Setup",
      description: "Seamlessly transition your legacy systems to modern cloud infrastructure with zero downtime. We handle AWS, GCP, and Azure setups tailored to your specific scale.",
      icon: Cloud,
    },
    {
      id: "service-cybersecurity",
      title: "Cybersecurity Analysis",
      description: "Comprehensive audits and penetration testing to secure your systems. We implement zero-trust architectures and provide ongoing threat monitoring.",
      icon: Shield,
    },
    {
      id: "service-data",
      title: "Data Engineering",
      description: "Build robust data pipelines and data warehouses. We specialize in real-time streaming, ETL processes, and setting up predictive analytics models.",
      icon: Database,
    },
    {
      id: "service-software",
      title: "Custom Software Development",
      description: "Scalable, high-performance web and mobile applications engineered to perfectly match your business requirements utilizing modern tech stacks.",
      icon: Code,
    }
  ];

  return (
    <section id="services" className="py-24 bg-white dark:bg-navy-900 border-t border-gray-100 dark:border-white/5 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern opacity-5" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-display font-medium text-gray-900 dark:text-white mb-4"
          >
            Our <span className="text-electric">Services</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto"
          >
            Specialized solutions designed to accelerate your growth and secure your digital assets.
          </motion.p>
        </div>

        <div className="space-y-24">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              id={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5 }}
              className={`flex flex-col md:flex-row gap-8 lg:gap-16 items-center scroll-mt-24 ${index % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}
            >
              <div className="flex-1 w-full relative">
                 <div className="aspect-video bg-gradient-to-br from-electric/5 to-cyan-500/5 dark:from-electric/10 dark:to-cyan-500/10 rounded-3xl border border-gray-100 dark:border-white/10 flex items-center justify-center p-12 relative overflow-hidden group">
                   <div className="absolute inset-0 bg-electric/10 blur-3xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                   <service.icon className="w-32 h-32 text-electric dark:text-cyan-400 relative z-10 drop-shadow-sm transition-transform duration-700 group-hover:scale-110" />
                 </div>
              </div>
              <div className="flex-1 w-full space-y-6">
                <div className="w-16 h-16 rounded-2xl bg-electric/10 flex items-center justify-center">
                  <service.icon className="w-8 h-8 text-electric" />
                </div>
                <h3 className="text-3xl font-display font-semibold text-gray-900 dark:text-white">
                  {service.title}
                </h3>
                <p className="text-lg text-gray-600 dark:text-gray-400 leading-relaxed">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
