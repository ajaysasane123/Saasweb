import { motion } from "motion/react";
import { Button } from "./ui/Button";
import { ArrowRight, ChevronRight, Activity, Zap, Shield } from "lucide-react";

import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

const chartData = [
  { name: 'Mon', revenue: 4000 },
  { name: 'Tue', revenue: 2000 },
  { name: 'Wed', revenue: 6000 },
  { name: 'Thu', revenue: 4500 },
  { name: 'Fri', revenue: 8000 },
  { name: 'Sat', revenue: 5500 },
  { name: 'Sun', revenue: 9000 },
];

export function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-electric to-purple-600 blur-[100px] rounded-full mask-radial-faded" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-gray-200 bg-white/50 dark:border-white/10 dark:bg-white/5 backdrop-blur-md mb-8 shadow-sm"
        >
          <span className="flex h-2 w-2 rounded-full bg-electric animate-pulse"></span>
          <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Nexus 2.0 is now live</span>
          <ChevronRight className="w-4 h-4 text-gray-400 dark:text-gray-500" />
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="font-display text-5xl md:text-7xl font-bold tracking-tight mb-8 leading-[1.1]"
        >
          Build the future of <br className="hidden md:block" />
          <span className="text-gradient-accent">enterprise software</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="max-w-2xl mx-auto text-lg md:text-xl text-gray-600 dark:text-gray-400 mb-10 leading-relaxed"
        >
          The ultimate platform for scaling your operations. Integrated analytics, seamless workflows, and enterprise-grade security—all in one place.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Button size="lg" className="w-full sm:w-auto group" onClick={() => window.location.hash = '#pricing'}>
            Start building for free
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button size="lg" variant="outline" className="w-full sm:w-auto" onClick={() => window.location.hash = '#contact'}>
            Book a demo
          </Button>
        </motion.div>

        {/* 3D Dashboard Mockup Presentation */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="mt-20 relative mx-auto max-w-5xl"
        >
          <div className="relative rounded-2xl border border-gray-200 bg-white/50 dark:border-white/10 dark:bg-navy-800/50 backdrop-blur-xl shadow-2xl overflow-hidden animate-float">
            <div className="h-12 border-b border-gray-200 dark:border-white/5 flex items-center px-4 gap-2 bg-gray-50/50 dark:bg-navy-900/50">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50" />
                <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50" />
              </div>
            </div>
            
            <div className="p-8 grid md:grid-cols-3 gap-6">
              <div className="md:col-span-2 space-y-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="h-12 w-12 rounded-xl bg-electric/10 dark:bg-electric/20 flex items-center justify-center border border-electric/20 dark:border-electric/30">
                    <Activity className="text-electric w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-semibold text-lg text-gray-900 dark:text-white">Revenue Overview</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">+24.5% compared to last week</p>
                  </div>
                </div>
                {/* Revenue Area Chart */}
                <div className="h-[250px] border border-gray-200 dark:border-white/5 rounded-xl bg-white dark:bg-white/[0.02] p-4 flex items-end gap-2 isolate relative shadow-sm">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#4F46E5" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="currentColor" className="text-gray-200 dark:text-gray-800" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 12 }} 
                        className="text-gray-500 dark:text-gray-400" 
                        dy={10}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 12 }} 
                        className="text-gray-500 dark:text-gray-400"
                        tickFormatter={(value) => `$${value / 1000}k`}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                          borderRadius: '8px', 
                          border: '1px solid #e5e7eb',
                          boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                        }}
                        labelStyle={{ color: '#374151', fontWeight: 600, marginBottom: '4px' }}
                        itemStyle={{ color: '#4F46E5', fontWeight: 500 }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="revenue" 
                        stroke="#4F46E5" 
                        strokeWidth={3}
                        fillOpacity={1} 
                        fill="url(#colorRevenue)" 
                        animationDuration={1500}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="space-y-6">
                <div className="p-6 rounded-xl border border-gray-200 dark:border-white/5 bg-gray-50 dark:bg-white/[0.02]">
                  <Zap className="w-8 h-8 text-yellow-500 mb-4" />
                  <h4 className="font-medium text-lg text-gray-900 dark:text-white">System Status</h4>
                  <p className="text-2xl font-bold font-display mt-2 text-gray-900 dark:text-white">Optimal</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">99.99% Uptime</p>
                </div>
                <div className="p-6 rounded-xl border border-gray-200 dark:border-white/5 bg-gray-50 dark:bg-white/[0.02]">
                  <Shield className="w-8 h-8 text-green-500 mb-4" />
                  <h4 className="font-medium text-lg text-gray-900 dark:text-white">Active Threats</h4>
                  <p className="text-2xl font-bold font-display mt-2 text-gray-900 dark:text-white">Zero</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Last scan: just now</p>
                </div>
              </div>
            </div>
            
            {/* Subtle glow underneath the dashboard */}
            <div className="absolute -inset-1 z-[-1] blur-2xl opacity-20 bg-gradient-to-r from-electric to-purple-600 rounded-2xl" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
