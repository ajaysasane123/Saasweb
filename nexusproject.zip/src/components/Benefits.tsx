import { motion } from "motion/react";
import { CheckCircle2, XCircle } from "lucide-react";

export function Benefits() {
  return (
    <section className="py-24 bg-gray-50 dark:bg-white/[0.02] border-y border-gray-200 dark:border-white/5 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
            A paradigm shift in architecture
          </h2>
          <p className="text-gray-600 dark:text-gray-400">Why the world's best engineering teams are moving to Nexus.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* traditional architecture */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="p-8 rounded-2xl border border-red-500/20 bg-red-50 dark:bg-red-500/5 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <span className="font-display font-bold text-6xl text-red-500 tracking-tighter">Legacy</span>
            </div>
            <h3 className="font-semibold text-xl mb-6 text-gray-900 dark:text-gray-200">The Old Way</h3>
            <ul className="space-y-4">
              {[
                "Managing multiple vendors and APIs",
                "Complex infrastructure scaling",
                "Fragmented data silos",
                "High latency queries due to poor caching",
                "Weeks to ship a new analytical dashboard"
              ].map((item, i) => (
                 <li key={i} className="flex items-start gap-3">
                   <XCircle className="w-5 h-5 text-red-400 mt-0.5 shrink-0" />
                   <span className="text-gray-600 dark:text-gray-400 text-sm">{item}</span>
                 </li>
              ))}
            </ul>
          </motion.div>

          {/* Nexus architecture */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="p-8 rounded-2xl border border-electric/30 glassmorphism bg-white/50 dark:bg-transparent relative overflow-hidden shadow-xl shadow-electric/5 dark:shadow-[0_0_40px_rgba(59,130,246,0.1)]"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <span className="font-display font-bold text-6xl text-electric tracking-tighter">Nexus</span>
            </div>
            <h3 className="font-semibold text-xl mb-6 text-gray-900 dark:text-white">The Nexus Way</h3>
            <ul className="space-y-4">
              {[
                "Unified API for all operations",
                "Serverless scale-to-zero infrastructure",
                "Real-time synchronized data layer",
                "Global edge caching out of the box",
                "Ship complex features in single sprints"
              ].map((item, i) => (
                 <li key={i} className="flex items-start gap-3">
                   <CheckCircle2 className="w-5 h-5 text-electric mt-0.5 shrink-0" />
                   <span className="text-gray-900 dark:text-white text-sm font-medium">{item}</span>
                 </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
