import { motion } from "motion/react";
import { Button } from "./ui/Button";
import { ArrowRight } from "lucide-react";

export function CTA() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-electric/5" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-3xl h-[600px] bg-gradient-to-r from-electric to-purple-600 blur-[150px] opacity-20 pointer-events-none rounded-full" />
      
      <div className="max-w-4xl mx-auto px-6 lg:px-8 relative z-10 text-center">
        <motion.div
           initial={{ opacity: 0, scale: 0.95 }}
           whileInView={{ opacity: 1, scale: 1 }}
           viewport={{ once: true }}
           className="p-12 rounded-3xl border border-white/10 glassmorphism bg-navy-800/80 shadow-2xl relative overflow-hidden"
        >
          {/* Subtle grid pattern background */}
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
          
          <div className="relative z-10">
            <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight mb-6">
              Ready to modernize your stack?
            </h2>
            <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
              Join thousands of engineering teams building the next generation of scalable applications on Nexus.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="w-full sm:w-auto group" onClick={() => window.location.hash = '#pricing'}>
                Start Building Today
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button size="lg" variant="ghost" className="w-full sm:w-auto" onClick={() => window.location.hash = '#contact'}>
                Talk to an Expert
              </Button>
            </div>
            <p className="mt-6 text-sm text-gray-500">No credit card required. 14-day free trial on Growth plan.</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
