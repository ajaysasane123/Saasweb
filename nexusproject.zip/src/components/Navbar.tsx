import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "./ui/Button";
import { Menu, X, Hexagon, LogOut, User } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { AuthModal } from "./AuthModal";
import { auth } from "../lib/firebase";
import { onAuthStateChanged, signOut, User as FirebaseUser } from "firebase/auth";

export function Navbar({ currentHash }: { currentHash?: string }) {
  const [scrolled, setScrolled] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [user, setUser] = useState<FirebaseUser | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  const handleOpenAuth = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
    setIsOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled ? "glassmorphism py-4 shadow-lg shadow-black/20" : "py-6 bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.location.hash = ''}>
            <Hexagon className="w-8 h-8 text-electric fill-electric/20" />
            <span className="font-display font-bold text-xl tracking-tight text-gray-900 dark:text-white">Nexus</span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            {[
              { label: "Platform", href: "#platform" },
              { label: "Solutions", href: "#solutions" },
              { label: "Pricing", href: "#pricing" },
              { label: "Docs", href: "#docs" }
            ].map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-sm font-medium text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white transition-colors"
                onClick={(e) => {
                  if (item.href.startsWith('#')) {
                     window.location.hash = item.href;
                  }
                }}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-4">
            <ThemeToggle />
            {user ? (
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                  <div className="w-8 h-8 rounded-full bg-electric/10 text-electric flex items-center justify-center">
                    <User className="w-4 h-4" />
                  </div>
                  {user.displayName || user.email}
                </div>
                <Button variant="ghost" size="sm" onClick={() => signOut(auth)}>
                  <LogOut className="w-4 h-4 mr-2" /> Sign Out
                </Button>
              </div>
            ) : (
              <>
                <Button variant="ghost" size="sm" onClick={() => handleOpenAuth('login')}>Log In</Button>
                <Button variant="primary" size="sm" onClick={() => handleOpenAuth('signup')}>Get Started</Button>
              </>
            )}
          </div>

          <div className="md:hidden flex items-center gap-4">
            <ThemeToggle />
            <button
              className="text-gray-600 dark:text-gray-300 p-2"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="absolute top-full left-4 right-4 mt-2 p-4 rounded-2xl glassmorphism border border-gray-200 dark:border-white/10 md:hidden flex flex-col gap-4 overflow-y-auto max-h-[80vh]"
          >
            {[
              { label: "Platform", href: "#platform" },
              { label: "Solutions", href: "#solutions" },
              { label: "Pricing", href: "#pricing" },
              { label: "Docs", href: "#docs" }
            ].map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-300 dark:hover:text-white p-2 rounded-lg dark:hover:bg-white/5"
                onClick={() => {
                  setIsOpen(false);
                  if (item.href.startsWith('#')) {
                    window.location.hash = item.href;
                  }
                }}
              >
                {item.label}
              </a>
            ))}

            <div className="px-2 pt-2 border-t border-gray-200 dark:border-white/10">
              <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Services</span>
              <div className="mt-2 flex flex-col gap-1">
                {[
                  { label: 'Cloud Migration & Setup', href: '#service-migration' },
                  { label: 'Cybersecurity Analysis', href: '#service-cybersecurity' },
                  { label: 'Data Engineering', href: '#service-data' },
                  { label: 'Custom Software Development', href: '#service-software' }
                ].map((service) => (
                  <a
                    key={service.label}
                    href={service.href}
                    className="text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-300 dark:hover:text-white p-2 rounded-lg dark:hover:bg-white/5"
                    onClick={() => {
                      setIsOpen(false);
                      window.location.hash = service.href;
                    }}
                  >
                    {service.label}
                  </a>
                ))}
              </div>
            </div>

            <div className="h-px bg-gray-200 dark:bg-white/10 my-2" />
            <div className="flex flex-col gap-2">
              {user ? (
                <>
                  <div className="flex items-center gap-3 p-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                     <div className="w-8 h-8 rounded-full bg-electric/10 text-electric flex items-center justify-center">
                       <User className="w-4 h-4" />
                     </div>
                     <span className="truncate">{user.displayName || user.email}</span>
                  </div>
                  <Button variant="ghost" className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10" onClick={() => { setIsOpen(false); signOut(auth); }}>
                    <LogOut className="w-4 h-4 mr-2" /> Sign Out
                  </Button>
                </>
              ) : (
                <>
                  <Button variant="ghost" className="w-full justify-start" onClick={() => handleOpenAuth('login')}>Log In</Button>
                  <Button variant="primary" className="w-full" onClick={() => handleOpenAuth('signup')}>Get Started</Button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AuthModal 
        isOpen={authModalOpen} 
        onClose={() => setAuthModalOpen(false)} 
        defaultMode={authMode} 
      />
    </motion.header>
  );
}
