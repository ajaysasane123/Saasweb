import { Hexagon, Twitter, Github, Linkedin } from "lucide-react";

export function Footer() {
  const links = [
    {
      title: "Product",
      items: [
        { name: "Features", href: "#platform" },
        { name: "Integrations", href: "#solutions" },
        { name: "Pricing", href: "#pricing" },
        { name: "Changelog", href: "#changelog" },
        { name: "Docs", href: "#docs" }
      ]
    },
    {
      title: "Company",
      items: [
        { name: "About Us", href: "#about" },
        { name: "Careers", href: "#careers" },
        { name: "Blog", href: "#blog" },
        { name: "Contact", href: "#contact" },
        { name: "Partners", href: "#partners" }
      ]
    },
    {
      title: "Legal",
      items: [
        { name: "Privacy Policy", href: "#privacy" },
        { name: "Terms of Service", href: "#terms" },
        { name: "Cookie Policy", href: "#cookies" },
        { name: "Security", href: "#security" }
      ]
    }
  ];

  const socialLinks = [
    { name: 'Twitter', icon: Twitter, url: 'https://twitter.com' },
    { name: 'GitHub', icon: Github, url: 'https://github.com' },
    { name: 'LinkedIn', icon: Linkedin, url: 'https://www.linkedin.com/in/ajay-ram-sasane-39642223a?utm_source=share_via&utm_content=profile&utm_medium=member_android' },
  ];

  return (
    <footer className="border-t border-gray-200 dark:border-white/5 bg-gray-50 dark:bg-navy-900 pt-16 pb-8 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-16">
          <div className="col-span-2 lg:col-span-2">
            <div className="flex items-center gap-2 mb-6 cursor-pointer" onClick={() => window.location.hash = ''}>
              <Hexagon className="w-6 h-6 text-electric fill-electric/20" />
              <span className="font-display font-bold text-lg tracking-tight text-gray-900 dark:text-white">Nexus</span>
            </div>
            <p className="text-gray-600 dark:text-gray-400 text-sm max-w-xs mb-6 leading-relaxed">
              The enterprise operating system for modern high-performance engineering teams.
            </p>
            <div className="flex gap-4">
              {socialLinks.map(({ name, icon: Icon, url }) => (
                <a key={name} href={url} target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-full bg-gray-200 dark:bg-white/5 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:text-gray-400 hover:bg-gray-300 dark:hover:text-white dark:hover:bg-white/10 transition-colors">
                  <span className="sr-only">{name}</span>
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {links.map((section) => (
            <div key={section.title}>
              <h3 className="font-semibold text-gray-900 dark:text-white mb-4">{section.title}</h3>
              <ul className="space-y-3">
                {section.items.map((item) => (
                  <li key={item.name}>
                    <a href={item.href} className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors">{item.name}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-gray-200 dark:border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">
             © {new Date().getFullYear()} Nexus Technologies Inc. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            All systems operational
          </div>
        </div>
      </div>
    </footer>
  );
}
