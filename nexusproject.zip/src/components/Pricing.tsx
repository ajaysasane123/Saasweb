import { useState } from "react";
import { motion } from "motion/react";
import { Button } from "./ui/Button";
import { Check } from "lucide-react";

export function Pricing() {
  const [annual, setAnnual] = useState(true);

  return (
    <section id="pricing" className="py-24 relative overflow-hidden transition-colors duration-300">
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-full h-1/2 bg-electric/10 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight mb-6 text-gray-900 dark:text-white">
            Predictable pricing <br className="hidden md:block" /> for any scale
          </h2>
          <div className="flex items-center justify-center gap-4 mt-8">
            <span className={`text-sm font-medium transition-colors ${!annual ? 'text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}>Monthly</span>
            <button 
              onClick={() => setAnnual(!annual)}
              className="relative inline-flex h-6 w-11 items-center rounded-full bg-electric/80 hover:bg-electric transition-colors"
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${annual ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
            <span className={`text-sm font-medium transition-colors ${annual ? 'text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}>
              Annually <span className="text-electric dark:text-electric text-xs ml-1 bg-electric/10 px-2 py-0.5 rounded-full border border-electric/20">Save 20%</span>
            </span>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Starter Plan */}
          <div className="p-8 rounded-2xl glassmorphism border-gray-200 dark:border-white/10 flex flex-col bg-white/50 dark:bg-transparent">
            <div className="mb-8">
              <h3 className="font-semibold text-xl mb-2 text-gray-900 dark:text-white">Developer</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">Perfect for side projects and learning.</p>
              <div className="flex items-baseline gap-1">
                 <span className="text-4xl font-bold font-display text-gray-900 dark:text-white">${annual ? '0' : '0'}</span>
                 <span className="text-gray-500 dark:text-gray-400 text-sm">/month</span>
              </div>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['10,000 events/mo', 'Community support', 'Basic analytics', '1 project'].map((f, i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-gray-700 dark:text-gray-300">
                  <Check className="w-4 h-4 text-electric shrink-0" /> {f}
                </li>
              ))}
            </ul>
            <Button variant="outline" className="w-full" onClick={() => window.location.hash = '#payment'}>Get Started</Button>
          </div>

          {/* Pro Plan */}
          <div className="p-8 rounded-2xl bg-white dark:bg-gradient-to-br dark:from-navy-800 dark:to-navy-900 border border-electric/50 shadow-xl shadow-electric/5 dark:shadow-[0_0_30px_rgba(59,130,246,0.15)] flex flex-col relative transform md:-translate-y-4">
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-electric to-purple-600 rounded-t-2xl" />
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-electric text-white text-xs font-bold rounded-full top-label">
              MOST POPULAR
            </div>
            <div className="mb-8 mt-2">
              <h3 className="font-semibold text-xl mb-2 text-gray-900 dark:text-white">Growth</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">For scaling startups and active teams.</p>
              <div className="flex items-baseline gap-1">
                 <span className="text-4xl font-bold font-display text-gray-900 dark:text-white">${annual ? '79' : '99'}</span>
                 <span className="text-gray-500 dark:text-gray-400 text-sm">/month</span>
              </div>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['1,000,000 events/mo', 'Priority email support', 'Advanced machine learning', 'Unlimited projects', 'Custom workflows'].map((f, i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-gray-900 dark:text-white font-medium">
                  <Check className="w-4 h-4 text-electric shrink-0" /> {f}
                </li>
              ))}
            </ul>
            <Button variant="primary" className="w-full" onClick={() => window.location.hash = '#payment'}>Start 14-day Free Trial</Button>
          </div>

          {/* Enterprise Plan */}
          <div className="p-8 rounded-2xl glassmorphism border-gray-200 dark:border-white/10 flex flex-col bg-white/50 dark:bg-transparent">
             <div className="mb-8">
              <h3 className="font-semibold text-xl mb-2 text-gray-900 dark:text-white">Enterprise</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">Custom infrastructure for mission-critical apps.</p>
              <div className="flex items-baseline gap-1">
                 <span className="text-4xl font-bold font-display text-gray-900 dark:text-white">Custom</span>
              </div>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['Unlimited events', '24/7 phone support', 'Dedicated success manager', 'SLA 99.99%', 'SOC2 & HIPAA Compliance', 'Custom contracts'].map((f, i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-gray-700 dark:text-gray-300">
                  <Check className="w-4 h-4 text-electric shrink-0" /> {f}
                </li>
              ))}
            </ul>
            <Button variant="outline" className="w-full" onClick={() => window.location.hash = '#contact'}>Contact Sales</Button>
          </div>
        </div>
      </div>
    </section>
  );
}
