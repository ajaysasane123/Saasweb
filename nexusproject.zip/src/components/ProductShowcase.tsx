import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { Copy, Terminal } from "lucide-react";

export function ProductShowcase() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const rotateX = useTransform(scrollYProgress, [0, 0.5, 1], [20, 0, -20]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.8, 1, 0.8]);

  return (
    <section id="solutions" ref={containerRef} className="py-32 relative perspective-1000">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center mb-16">
         <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight mb-6 text-gray-900 dark:text-white">
          Code built for <br />
          <span className="text-gradient">developers</span>
        </h2>
        <p className="text-gray-600 dark:text-gray-400 max-w-xl mx-auto text-lg">
          Integrate our unified API in minutes. Strongly typed SDKs available for modern languages.
        </p>
      </div>

      <motion.div 
        style={{ rotateX, scale, transformStyle: "preserve-3d" }}
        className="max-w-4xl mx-auto px-6 relative z-10"
      >
        <div className="rounded-2xl border border-white/10 bg-[#0d1117] shadow-2xl overflow-hidden glassmorphism">
          {/* Editor Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-[#161b22]">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-gray-400" />
              <span className="text-sm font-mono text-gray-400">nexusConfig.ts</span>
            </div>
            <button className="text-gray-500 hover:text-white transition-colors">
              <Copy className="w-4 h-4" />
            </button>
          </div>
          
          {/* Editor Body */}
          <div className="p-6 overflow-x-auto text-left">
            <pre className="font-mono text-sm leading-relaxed">
              <code className="text-gray-300">
<span className="text-pink-400">import</span> {"{ NexusClient }"} <span className="text-pink-400">from</span> <span className="text-green-300">'@nexus/node'</span>;
<br />
<span className="text-pink-400">const</span> client = <span className="text-pink-400">new</span> <span className="text-yellow-200">NexusClient</span>({"{ "}<br />
  apiKey: process.env.<span className="text-blue-300">NEXUS_API_KEY</span>,<br />
  environment: <span className="text-green-300">'production'</span>,<br />
  region: <span className="text-green-300">'us-east-1'</span><br />
{"}"});
<br /><br />
<span className="text-gray-500">// Initialize high-performance event pipeline</span><br />
<span className="text-pink-400">await</span> client.events.<span className="text-blue-200">ingest</span>([{"{ "}<br />
  event_type: <span className="text-green-300">'user.signup'</span>,<br />
  user_id: <span className="text-green-300">'usr_9xjd82k'</span>,<br />
  metadata: {"{ "} plan: <span className="text-green-300">'enterprise'</span> {"}"}<br />
{"}"}]);
<br /><br />
<span className="text-gray-500">// Get predictive insights immediately</span><br />
<span className="text-pink-400">const</span> prediction = <span className="text-pink-400">await</span> client.ml.<span className="text-blue-200">predictLTV</span>(<span className="text-green-300">'usr_9xjd82k'</span>);<br />
console.<span className="text-blue-200">log</span>(prediction.confidenceScore);
              </code>
            </pre>
          </div>
        </div>
        
        {/* Glow behind code editor */}
        <div className="absolute -inset-4 z-[-1] blur-3xl opacity-20 bg-gradient-to-tr from-electric via-purple-600 to-pink-500" />
      </motion.div>
    </section>
  );
}
