import { motion } from "motion/react";
import { Layers, Workflow, Fingerprint, LineChart, Globe, Zap } from "lucide-react";

export function Features() {
  const features = [
    {
      title: "Advanced Analytics",
      description: "Real-time insights powered by custom models. Make decisions faster with predictive analytics and automated reporting.",
      icon: LineChart,
      color: "text-blue-500"
    },
    {
      title: "Infinite Scale",
      description: "Built on edge infrastructure to guarantee sub-50ms latency globally. Deploys to 35+ regions instantly.",
      icon: Globe,
      color: "text-purple-500"
    },
    {
      title: "Bank-grade Security",
      description: "SOC2 Type II certified. Advanced encryption at rest and in transit with mandatory hardware 2FA.",
      icon: Fingerprint,
      color: "text-green-500"
    },
    {
      title: "Custom Workflows",
      description: "Visual workflow builder to automate redundant tasks. Connects with over 500+ premium APIs.",
      icon: Workflow,
      color: "text-yellow-500"
    },
    {
      title: "Multi-tenant Architecture",
      description: "Logically isolated data stores for maximum privacy combined with shared infrastructure efficiency.",
      icon: Layers,
      color: "text-pink-500"
    },
    {
      title: "Real-time Processing",
      description: "Event-driven architecture processes millions of events per second without dropping a single packet.",
      icon: Zap,
      color: "text-orange-500"
    }
  ];

  return (
    <section id="platform" className="py-24 lg:py-32 relative bg-gray-50/30 dark:bg-transparent transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="mb-16 md:text-center">
          <h2 className="text-gray-900 dark:text-white font-display text-3xl md:text-4xl font-bold tracking-tight mb-4">
            Everything you need to <span className="text-gradient">scale</span>
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg max-w-2xl mx-auto">
            A comprehensive suite of tools designed specifically for high-growth engineering teams. Stop building infrastructure, start building product.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative p-8 rounded-2xl glassmorphism border-gray-200 dark:border-white/5 bg-white/50 dark:bg-transparent hover:bg-white dark:hover:bg-white/[0.04] hover:shadow-lg dark:hover:shadow-none transition-all duration-300"
            >
              {/* Subtle hover gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-electric/5 dark:from-electric/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl" />
              
              <div className="relative z-10">
                <div className={`w-12 h-12 rounded-xl bg-gray-50 dark:bg-white/5 flex items-center justify-center border border-gray-200 dark:border-white/10 mb-6 group-hover:scale-110 transition-transform shadow-sm dark:shadow-none ${feature.color}`}>
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="text-gray-900 dark:text-white text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
