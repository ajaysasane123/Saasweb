import { motion } from "motion/react";
import { Button } from "./ui/Button";
import { CreditCard, Lock, CheckCircle2, ShieldCheck, Zap } from "lucide-react";
import React, { useState, useEffect } from "react";
import { Toast } from "./ui/Toast";

export function PaymentSection() {
  const [loading, setLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [errorObj, setErrorObj] = useState<string | null>(null);

  useEffect(() => {
    // Check URL parameters for Stripe success/cancel
    const query = new URLSearchParams(window.location.search);
    if (query.get("payment_success")) {
      setIsSuccess(true);
      setShowToast(true);
      // Clean up URL while keeping hash
      window.history.replaceState({}, document.title, window.location.pathname + window.location.hash);
    }
    if (query.get("payment_canceled")) {
      setErrorObj("Payment was canceled. You can try again below.");
      window.history.replaceState({}, document.title, window.location.pathname + window.location.hash);
    }
  }, []);

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorObj(null);
    
    // Simulate payment processing without external dependencies
    setTimeout(() => {
      setLoading(false);
      setIsSuccess(true);
      setShowToast(true);
    }, 2000);
  };

  if (isSuccess) {
    return (
      <section id="payment" className="py-32 relative overflow-hidden bg-gray-50 dark:bg-white/[0.01] border-t border-gray-200 dark:border-white/5 transition-colors duration-300">
        <Toast message="Payment completed successfully!" isOpen={showToast} onClose={() => setShowToast(false)} />
        <div className="max-w-2xl mx-auto px-6 lg:px-8 relative z-10 text-center">
          <motion.div
             initial={{ opacity: 0, scale: 0.95 }}
             animate={{ opacity: 1, scale: 1 }}
             className="p-12 rounded-3xl border border-electric/30 glassmorphism bg-white/80 dark:bg-navy-800/80 shadow-[0_0_40px_rgba(59,130,246,0.15)] relative overflow-hidden"
          >
            <div className="w-20 h-20 rounded-full bg-green-100 dark:bg-green-500/20 text-green-600 dark:text-green-400 mx-auto flex items-center justify-center mb-6">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h2 className="font-display text-4xl font-bold tracking-tight mb-4 text-gray-900 dark:text-white">Payment Successful</h2>
            <p className="text-gray-600 dark:text-gray-400 text-lg mb-8 max-w-md mx-auto">
              Welcome to Nexus. Your enterprise account has been successfully provisioned. We've sent a receipt to your email.
            </p>
            <Button size="lg" variant="primary" onClick={() => setIsSuccess(false)}>
              Access Dashboard
            </Button>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id="payment" className="py-24 relative overflow-hidden bg-gray-50 dark:bg-white/[0.01] border-t border-gray-200 dark:border-white/5 transition-colors duration-300">
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-electric/10 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="max-w-4xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl font-bold tracking-tight mb-2">Secure Checkout</h2>
          <p className="text-gray-400 text-lg">Complete your subscription via our secure Stripe payment gateway.</p>
        </div>

        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           className="grid md:grid-cols-2 gap-px rounded-3xl border border-white/10 glassmorphism bg-white/5 shadow-2xl relative overflow-hidden"
        >
          {/* Order Summary */}
          <div className="p-8 md:p-12 bg-gray-50/80 dark:bg-navy-800/80 transition-colors duration-300">
            <h3 className="text-xl font-semibold mb-6 flex items-center gap-2 text-gray-900 dark:text-white">
              <Zap className="w-5 h-5 text-electric" /> Nexus Pro Plan
            </h3>
            
            <div className="flex justify-between items-end border-b border-gray-200 dark:border-white/10 pb-6 mb-6">
              <div>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-1">Billed Monthly</p>
                <div className="text-3xl font-display font-bold text-gray-900 dark:text-white">
                  $99<span className="text-lg text-gray-500">.00</span>
                </div>
              </div>
            </div>
            
            <ul className="space-y-4 mb-8">
              {[
                "1,000,000 events/mo included",
                "Advanced machine learning insights",
                "Unlimited projects & deployments",
                "Billed securely via Stripe"
              ].map((item, i) => (
                 <li key={i} className="flex items-start gap-3">
                   <CheckCircle2 className="w-5 h-5 text-electric shrink-0" />
                   <span className="text-gray-700 dark:text-gray-300 text-sm">{item}</span>
                 </li>
              ))}
            </ul>
          </div>

          {/* Checkout Action */}
          <div className="p-8 md:p-12 bg-white dark:bg-navy-900/80 flex flex-col justify-center transition-colors duration-300">
            <div className="mb-6 text-center">
              <h4 className="font-medium text-gray-900 dark:text-white text-lg mb-2">Payment Details</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Complete your registration securely.
              </p>
            </div>

            {errorObj && (
              <div className="mb-6 p-4 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-600 dark:text-red-400 text-sm">
                {errorObj}
              </div>
            )}

            <form onSubmit={handleCheckout} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-700 dark:text-gray-300">Name on Card</label>
                <input type="text" placeholder="John Doe" className="w-full bg-gray-50 dark:bg-navy-800 border border-gray-200 dark:border-white/10 rounded-lg px-4 py-2.5 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-electric transition-shadow" required />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-700 dark:text-gray-300">Card Information</label>
                <div className="relative">
                  <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input type="text" placeholder="0000 0000 0000 0000" className="w-full bg-gray-50 dark:bg-navy-800 border border-gray-200 dark:border-white/10 rounded-lg pl-11 pr-4 py-2.5 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-electric transition-shadow" required />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-gray-700 dark:text-gray-300">Expiry Date</label>
                  <input type="text" placeholder="MM/YY" className="w-full bg-gray-50 dark:bg-navy-800 border border-gray-200 dark:border-white/10 rounded-lg px-4 py-2.5 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-electric transition-shadow" required />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-gray-700 dark:text-gray-300">CVC</label>
                  <input type="text" placeholder="123" className="w-full bg-gray-50 dark:bg-navy-800 border border-gray-200 dark:border-white/10 rounded-lg px-4 py-2.5 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-electric transition-shadow" required />
                </div>
              </div>

              <Button type="submit" className="w-full h-12 mt-2" disabled={loading}>
                <Lock className="w-4 h-4 mr-2" />
                {loading ? "Processing..." : "Process Payment"}
              </Button>
            </form>

            <div className="mt-6 flex justify-center items-center gap-2 opacity-50">
              <span className="text-xs text-gray-400 font-medium">SECURE PROTOTYPE</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
