import React, { useState } from "react";
import { Button } from "./ui/Button";

export function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email address is invalid";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Message is required";
    }
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setFormData({ name: "", email: "", message: "" });
    }, 1500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    // Clear error for the field when typing
    if (errors[e.target.name]) {
      setErrors({
        ...errors,
        [e.target.name]: ""
      });
    }
  };

  if (isSuccess) {
    return (
      <div className="p-8 rounded-2xl glassmorphism border-electric/30 bg-electric/5 text-center transition-colors duration-300">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Message Sent!</h3>
        <p className="text-gray-600 dark:text-gray-400 mb-6">Thank you for reaching out. Our team will get back to you shortly.</p>
        <Button onClick={() => setIsSuccess(false)} variant="outline">
          Send another message
        </Button>
      </div>
    );
  }

  return (
    <form className="space-y-4 p-8 rounded-2xl glassmorphism border-gray-200 dark:border-white/5 bg-white/50 dark:bg-transparent transition-colors duration-300" onSubmit={handleSubmit}>
      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
        <input 
          type="text" 
          name="name"
          value={formData.name}
          onChange={handleChange}
          className={`w-full bg-white dark:bg-navy-900 border rounded-xl px-4 py-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 transition-all duration-300 ${errors.name ? 'border-red-500/50 focus:ring-red-500/50' : 'border-gray-200 dark:border-white/10 focus:ring-electric hover:border-gray-300 dark:hover:border-white/20'}`} 
        />
        {errors.name && <p className="text-red-500 dark:text-red-400 text-xs mt-1">{errors.name}</p>}
      </div>
      
      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Email</label>
        <input 
          type="email" 
          name="email"
          value={formData.email}
          onChange={handleChange}
          className={`w-full bg-white dark:bg-navy-900 border rounded-xl px-4 py-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 transition-all duration-300 ${errors.email ? 'border-red-500/50 focus:ring-red-500/50' : 'border-gray-200 dark:border-white/10 focus:ring-electric hover:border-gray-300 dark:hover:border-white/20'}`} 
        />
        {errors.email && <p className="text-red-500 dark:text-red-400 text-xs mt-1">{errors.email}</p>}
      </div>
      
      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Message</label>
        <textarea 
          rows={4} 
          name="message"
          value={formData.message}
          onChange={handleChange}
          className={`w-full bg-white dark:bg-navy-900 border rounded-xl px-4 py-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 resize-none transition-all duration-300 ${errors.message ? 'border-red-500/50 focus:ring-red-500/50' : 'border-gray-200 dark:border-white/10 focus:ring-electric hover:border-gray-300 dark:hover:border-white/20'}`} 
        />
        {errors.message && <p className="text-red-500 dark:text-red-400 text-xs mt-1">{errors.message}</p>}
      </div>
      
      <Button type="submit" className="w-full" disabled={isSubmitting}>
        {isSubmitting ? "Sending..." : "Send Message"}
      </Button>
    </form>
  );
}
