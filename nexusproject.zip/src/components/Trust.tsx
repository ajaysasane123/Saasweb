import { motion } from "motion/react";

export function Trust() {
  const logos = [
    { name: "Acme Corp", icon: "â³" },
    { name: "Global Tech", icon: "â²" },
    { name: "Nexus Systems", icon: "â±" },
    { name: "Quantum", icon: "â°" },
    { name: "Stellar", icon: "â¯" },
    { name: "Horizon", icon: "â®" },
  ];

  return (
    <section className="py-20 border-y border-gray-200 dark:border-white/5 bg-gray-50/50 dark:bg-white/[0.01] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
        <p className="text-sm font-medium text-gray-500 tracking-wider uppercase mb-10">
          Trusted by innovative teams worldwide
        </p>
        
        {/* Simple marquee effect */}
        <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-8 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
          {logos.map((logo, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center gap-2 text-2xl font-display font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors"
            >
              <span className="text-electric">{logo.icon}</span>
              {logo.name}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
