import { motion } from "motion/react";
import React, { useEffect } from "react";
import { Button } from "./ui/Button";
import { ContactForm } from "./ContactForm";

const contentMap: Record<string, { title: string; subtitle: string; content: React.ReactNode }> = {
  '#changelog': {
    title: "Changelog",
    subtitle: "The latest updates and improvements to the Nexus platform.",
    content: (
      <div className="space-y-12">
        <div className="border-l-2 border-electric pl-6 pb-2 relative">
          <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-electric" />
          <span className="text-sm text-electric font-mono mb-2 block">v2.4.0 - October 24, 2026</span>
          <h3 className="text-2xl font-bold mb-3 text-gray-900 dark:text-gray-900 dark:text-white">Enterprise SSO & Role-Based Access</h3>
          <p className="text-gray-600 dark:text-gray-600 dark:text-gray-400 mb-4 text-sm md:text-base">Added support for SAML and OIDC providers including Okta, Azure AD, and Google Workspace. Administrators can now define fine-grained RBAC policies across all resources and environments.</p>
          <ul className="list-disc list-inside text-gray-600 dark:text-gray-600 dark:text-gray-400 text-sm space-y-1">
            <li>New Integration: Okta SAML 2.0</li>
            <li>Custom Roles: Define permissions per API endpoint.</li>
            <li>Audit Logs: Track authentication events in real-time.</li>
          </ul>
        </div>
        <div className="border-l-2 border-gray-200 dark:border-gray-200 dark:border-white/10 pl-6 pb-2 relative">
          <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-white/20" />
          <span className="text-sm text-gray-500 dark:text-gray-500 dark:text-gray-500 dark:text-gray-500 font-mono mb-2 block">v2.3.5 - September 12, 2026</span>
          <h3 className="text-2xl font-bold mb-3 text-gray-900 dark:text-gray-900 dark:text-white">Predictive Edge Caching</h3>
          <p className="text-gray-600 dark:text-gray-600 dark:text-gray-400 text-sm md:text-base">Our ML model now preemptively caches assets at edge nodes based on historical traffic patterns, leading to a 40% reduction in global TTFB.</p>
        </div>
        <div className="border-l-2 border-gray-200 dark:border-gray-200 dark:border-white/10 pl-6 pb-2 relative">
          <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-white/20" />
          <span className="text-sm text-gray-500 dark:text-gray-500 dark:text-gray-500 dark:text-gray-500 font-mono mb-2 block">v2.3.0 - August 05, 2026</span>
          <h3 className="text-2xl font-bold mb-3 text-gray-900 dark:text-gray-900 dark:text-white">Advanced Telemetry SDKs</h3>
          <p className="text-gray-600 dark:text-gray-600 dark:text-gray-400 text-sm md:text-base">Released official telemetry SDKs for Rust, Go, and Python. Seamlessly trace distributed systems with zero configuration.</p>
        </div>
      </div>
    )
  },
  '#docs': {
    title: "Documentation",
    subtitle: "Everything you need to integrate and deploy with Nexus.",
    content: (
      <div className="grid md:grid-cols-2 gap-8">
        <div className="p-6 rounded-2xl glassmorphism border-gray-200 dark:border-gray-200 dark:border-white/5">
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-4">Getting Started</h3>
          <ul className="space-y-3 text-gray-600 dark:text-gray-600 dark:text-gray-400">
            <li><a href="#" className="hover:text-electric transition-colors">Quickstart Guide</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Authentication</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Environment Setup</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Core Concepts</a></li>
          </ul>
        </div>
        <div className="p-6 rounded-2xl glassmorphism border-gray-200 dark:border-gray-200 dark:border-white/5">
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-4">API Reference</h3>
          <ul className="space-y-3 text-gray-600 dark:text-gray-600 dark:text-gray-400">
            <li><a href="#" className="hover:text-electric transition-colors">REST API</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">GraphQL Endpoint</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Webhooks</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Rate Limits</a></li>
          </ul>
        </div>
        <div className="p-6 rounded-2xl glassmorphism border-gray-200 dark:border-gray-200 dark:border-white/5">
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-4">SDKs</h3>
          <ul className="space-y-3 text-gray-600 dark:text-gray-600 dark:text-gray-400">
            <li><a href="#" className="hover:text-electric transition-colors">Node.js / TypeScript</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Python</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Go</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Rust</a></li>
          </ul>
        </div>
        <div className="p-6 rounded-2xl glassmorphism border-gray-200 dark:border-gray-200 dark:border-white/5">
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-4">Architecture</h3>
          <ul className="space-y-3 text-gray-600 dark:text-gray-600 dark:text-gray-400">
            <li><a href="#" className="hover:text-electric transition-colors">Event Processing</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Edge Network</a></li>
            <li><a href="#" className="hover:text-electric transition-colors">Data Privacy</a></li>
          </ul>
        </div>
      </div>
    )
  },
  '#about': {
    title: "About Us",
    subtitle: "We are building the enterprise operating system of the future.",
    content: (
      <div className="space-y-8 text-gray-700 dark:text-gray-700 dark:text-gray-300">
        <p className="text-lg leading-relaxed">
          Founded in 2024 by a team of ex-infrastructure engineers from the world's most demanding tech companies, Nexus was created to solve a single problem: building scalable enterprise software is too complex.
        </p>
        <p className="text-lg leading-relaxed">
          We believe that engineering teams should focus on unique business logic and user experiences, not wiring together disparate APIs, managing state across edge regions, or worrying about compliance.
        </p>
        <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mt-12 mb-4">By the numbers</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="p-6 rounded-xl border border-gray-200 dark:border-gray-200 dark:border-white/5 bg-gray-100 dark:bg-gray-100 dark:bg-white/5">
            <div className="text-3xl font-display font-bold text-electric mb-2">35+</div>
            <div className="text-sm text-gray-600 dark:text-gray-600 dark:text-gray-400">Global Regions</div>
          </div>
          <div className="p-6 rounded-xl border border-gray-200 dark:border-gray-200 dark:border-white/5 bg-gray-100 dark:bg-gray-100 dark:bg-white/5">
            <div className="text-3xl font-display font-bold text-electric mb-2">1B+</div>
            <div className="text-sm text-gray-600 dark:text-gray-600 dark:text-gray-400">Events/Day</div>
          </div>
          <div className="p-6 rounded-xl border border-gray-200 dark:border-gray-200 dark:border-white/5 bg-gray-100 dark:bg-gray-100 dark:bg-white/5">
            <div className="text-3xl font-display font-bold text-electric mb-2">99.99%</div>
            <div className="text-sm text-gray-600 dark:text-gray-600 dark:text-gray-400">Uptime SLA</div>
          </div>
          <div className="p-6 rounded-xl border border-gray-200 dark:border-gray-200 dark:border-white/5 bg-gray-100 dark:bg-gray-100 dark:bg-white/5">
            <div className="text-3xl font-display font-bold text-electric mb-2">150+</div>
            <div className="text-sm text-gray-600 dark:text-gray-600 dark:text-gray-400">Employees</div>
          </div>
        </div>
      </div>
    )
  },
  '#careers': {
    title: "Careers",
    subtitle: "Join us in redefining infrastructure.",
    content: (
      <div className="space-y-12">
        <div className="prose prose-invert max-w-none text-gray-700 dark:text-gray-700 dark:text-gray-300">
          <p className="text-lg">We are a remote-first, async-heavy culture focused on high-quality engineering and design. We offer top-tier compensation, excellent health coverage, and flexible working hours.</p>
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-6">Open Roles</h3>
          <div className="space-y-4">
            {[
              { role: "Senior Frontend Engineer", team: "Product", type: "Remote, US/EU" },
              { role: "Distributed Systems Engineer", team: "Core Infra", type: "Remote, Global" },
              { role: "Developer Advocate", team: "DevRel", type: "London or Remote" },
              { role: "Product Designer", team: "Design", type: "Remote, US" },
            ].map((job, i) => (
               <div key={i} className="flex flex-col md:flex-row md:items-center justify-between p-6 rounded-xl border border-gray-200 dark:border-gray-200 dark:border-white/5 bg-gray-50 dark:bg-gray-50 dark:bg-white/[0.02] hover:bg-gray-100 dark:bg-gray-100 dark:bg-white/[0.05] transition-colors cursor-pointer">
                 <div>
                   <h4 className="font-semibold text-gray-900 dark:text-gray-900 dark:text-white text-lg">{job.role}</h4>
                   <p className="text-sm text-gray-600 dark:text-gray-600 dark:text-gray-400 mt-1">{job.team} &middot; {job.type}</p>
                 </div>
                 <Button variant="outline" size="sm" className="mt-4 md:mt-0 w-max">Apply Now</Button>
               </div>
            ))}
          </div>
        </div>
      </div>
    )
  },
  '#blog': {
    title: "Blog",
    subtitle: "Insights, updates, and engineering deep-dives.",
    content: (
      <div className="grid gap-8">
        {[
          { title: "How we process 1 Billion events per day with Rust", date: "Oct 15, 2026", category: "Engineering" },
          { title: "Introducing the Nexus Global Edge Network", date: "Sep 28, 2026", category: "Product" },
          { title: "Why we abandoned GraphQL for a custom unified RPC", date: "Aug 10, 2026", category: "Architecture" },
          { title: "SOC2 Compliance: A practitioner's guide", date: "Jul 22, 2026", category: "Security" },
        ].map((post, i) => (
          <div key={i} className="group p-6 rounded-2xl border border-gray-200 dark:border-gray-200 dark:border-white/5 bg-gray-50 dark:bg-gray-50 dark:bg-white/[0.02] hover:border-electric/30 transition-colors cursor-pointer">
            <div className="flex items-center gap-3 mb-3 text-sm">
              <span className="text-electric font-medium">{post.category}</span>
              <span className="text-gray-600">&middot;</span>
              <span className="text-gray-600 dark:text-gray-600 dark:text-gray-400">{post.date}</span>
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-gray-900 dark:text-white group-hover:text-electric transition-colors">{post.title}</h3>
            <p className="mt-3 text-gray-600 dark:text-gray-600 dark:text-gray-400 text-sm">Read the full article &rarr;</p>
          </div>
        ))}
      </div>
    )
  },
  '#contact': {
    title: "Contact Us",
    subtitle: "Get in touch with our team.",
    content: (
      <div className="grid md:grid-cols-2 gap-12">
        <div>
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-4">Reach out</h3>
          <p className="text-gray-600 dark:text-gray-600 dark:text-gray-400 mb-8">For general inquiries, partnership opportunities, or media requests, please fill out the form or contact us directly.</p>
          
          <div className="space-y-6">
            <div>
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-700 dark:text-gray-300">Sales</h4>
              <a href="mailto:sales@nexus.com" className="text-electric hover:underline">sales@nexus.com</a>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-700 dark:text-gray-300">Support</h4>
              <a href="mailto:support@nexus.com" className="text-electric hover:underline">support@nexus.com</a>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-700 dark:text-gray-300">HQ</h4>
              <p className="text-gray-600 dark:text-gray-600 dark:text-gray-400">100 Innovation Way<br/>San Francisco, CA 94105</p>
            </div>
          </div>
        </div>
        
        <ContactForm />
      </div>
    )
  },
  '#partners': {
    title: "Partners Program",
    subtitle: "Grow your business by building with Nexus.",
    content: (
      <div className="space-y-8 text-gray-700 dark:text-gray-700 dark:text-gray-300">
        <p className="text-lg leading-relaxed">
          The Nexus ecosystem thrives on our partnerships with leading agencies, system integrators, and technology platforms. By joining the Partners Program, you gain access to dedicated support, revenue sharing, and co-marketing opportunities.
        </p>
        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <div className="p-6 border border-gray-200 dark:border-gray-200 dark:border-white/5 rounded-xl bg-gray-100 dark:bg-gray-100 dark:bg-white/5">
            <h3 className="text-lg font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-2">Technology Partners</h3>
            <p className="text-sm text-gray-600 dark:text-gray-600 dark:text-gray-400">Integrate your software with our unified API to offer a seamless experience for mutual customers.</p>
          </div>
          <div className="p-6 border border-gray-200 dark:border-gray-200 dark:border-white/5 rounded-xl bg-gray-100 dark:bg-gray-100 dark:bg-white/5">
            <h3 className="text-lg font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-2">Agency Partners</h3>
            <p className="text-sm text-gray-600 dark:text-gray-600 dark:text-gray-400">Build high-performance applications for your clients using our enterprise infrastructure.</p>
          </div>
        </div>
        <div className="mt-8">
          <Button variant="primary">Become a Partner</Button>
        </div>
      </div>
    )
  },
  '#privacy': {
    title: "Privacy Policy",
    subtitle: "Last updated: October 1, 2026",
    content: (
      <div className="prose prose-invert max-w-none text-gray-700 dark:text-gray-700 dark:text-gray-300 space-y-6">
        <p>At Nexus Technologies Inc. ("Nexus", "we", "us", or "our"), your privacy is a top priority. This Privacy Policy outlines how we collect, use, and protect your data when you use our website, APIs, and platform.</p>
        
        <h3 className="text-gray-900 dark:text-gray-900 dark:text-white text-xl font-bold mt-8">1. Information We Collect</h3>
        <p>We collect information you explicitly provide (such as your name, email, and billing details) and technical data automatically collected when you interact with our platform (such as IP addresses, telemetry, and cookie identifiers).</p>
        
        <h3 className="text-gray-900 dark:text-gray-900 dark:text-white text-xl font-bold mt-8">2. How We Use Your Data</h3>
        <p>We use the data to provide, maintain, and improve our services, process transactions securely via our partners (e.g., Stripe), and communicate with you about updates, security alerts, and support requests.</p>
        
        <h3 className="text-gray-900 dark:text-gray-900 dark:text-white text-xl font-bold mt-8">3. Data Sharing and Subprocessors</h3>
        <p>We never sell your personal data. We may share information with trusted third-party subprocessors who assist us in operating our platform, subject to strict confidentiality agreements.</p>
      </div>
    )
  },
  '#terms': {
    title: "Terms of Service",
    subtitle: "Last updated: October 1, 2026",
    content: (
      <div className="prose prose-invert max-w-none text-gray-700 dark:text-gray-700 dark:text-gray-300 space-y-6">
        <p>These Terms of Service ("Terms") govern your use of the platforms and APIs provided by Nexus Technologies Inc. By accessing our services, you agree to comply with these terms.</p>
        
        <h3 className="text-gray-900 dark:text-gray-900 dark:text-white text-xl font-bold mt-8">1. Use of Services</h3>
        <p>You may use our services solely for lawful purposes. You agree not to distribute malicious software, attempt to breach our security mechanisms, or engage in activity that degrades platform performance for others.</p>
        
        <h3 className="text-gray-900 dark:text-gray-900 dark:text-white text-xl font-bold mt-8">2. Uptime and SLAs</h3>
        <p>Enterprise users are guaranteed a 99.99% uptime SLA. In the event of downtime exceeding this threshold, eligible customers will receive service credits as outlined in their specific enterprise contracts.</p>
        
        <h3 className="text-gray-900 dark:text-gray-900 dark:text-white text-xl font-bold mt-8">3. Termination</h3>
        <p>We reserve the right to suspend or terminate access to our services if we determine a violation of these terms has occurred. Customers may terminate their subscription at any time.</p>
      </div>
    )
  },
  '#cookies': {
    title: "Cookie Policy",
    subtitle: "How we use cookies and tracking technologies.",
    content: (
      <div className="prose prose-invert max-w-none text-gray-700 dark:text-gray-700 dark:text-gray-300 space-y-6">
        <p>We use cookies to improve your browsing experience, analyze site traffic, and understand where our audience comes from.</p>
        <h3 className="text-gray-900 dark:text-gray-900 dark:text-white text-xl font-bold mt-8">Essential Cookies</h3>
        <p>These cookies are strictly necessary for the platform to function, such as managing your session and securing authentication flows.</p>
        <h3 className="text-gray-900 dark:text-gray-900 dark:text-white text-xl font-bold mt-8">Analytics Cookies</h3>
        <p>With your consent, we use analytics cookies to track usage patterns and performance metrics, allowing us to continuously improve the Nexus platform.</p>
      </div>
    )
  },
  '#security': {
    title: "Security",
    subtitle: "Enterprise-grade security at every layer.",
    content: (
      <div className="space-y-8 text-gray-700 dark:text-gray-700 dark:text-gray-300">
        <p className="text-lg leading-relaxed">
          Security is built into the core of the Nexus platform. From physical infrastructure to application-layer defense, we utilize state-of-the-art mechanisms to ensure your data remains completely confidential and highly available.
        </p>
        
        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <div className="p-6 rounded-2xl border border-gray-200 dark:border-gray-200 dark:border-white/5 bg-gray-100 dark:bg-gray-100 dark:bg-white/5">
            <h3 className="text-xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-3">Compliance & Certifications</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-green-500"/> SOC 2 Type II Certified</li>
              <li className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-green-500"/> GDPR & CCPA Compliant</li>
              <li className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-green-500"/> HIPAA Compliant (Enterprise)</li>
              <li className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-green-500"/> PCI-DSS Level 1</li>
            </ul>
          </div>
          
          <div className="p-6 rounded-2xl border border-gray-200 dark:border-gray-200 dark:border-white/5 bg-gray-100 dark:bg-gray-100 dark:bg-white/5">
            <h3 className="text-xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-3">Encryption</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-electric"/> AES-256 Encryption at Rest</li>
              <li className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-electric"/> TLS 1.3 in Transit</li>
              <li className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-electric"/> Automated Key Rotation</li>
              <li className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-electric"/> Hardware Security Modules (HSMs)</li>
            </ul>
          </div>
        </div>

        <div className="p-8 rounded-2xl border border-electric/30 bg-electric/5 mt-8">
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-900 dark:text-white mb-3">Bug Bounty Program</h3>
          <p className="mb-4">We run a private bug bounty program through HackerOne. If you believe you have found a security vulnerability in Nexus, please report it to us safely.</p>
          <Button variant="outline" onClick={() => window.location.hash = '#contact'}>Report a Vulnerability</Button>
        </div>
      </div>
    )
  }
};

export const infoPagesList = Object.keys(contentMap);

export function InfoPage({ hash }: { hash: string }) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [hash]);

  const page = contentMap[hash];
  if (!page) return null;

  return (
    <motion.div 
      key={hash}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4 }}
      className="pt-32 pb-24 max-w-4xl mx-auto px-6 lg:px-8 min-h-[70vh]"
    >
      <div className="mb-16">
        <h1 className="text-4xl md:text-5xl font-display font-bold tracking-tight text-gray-900 dark:text-gray-900 dark:text-white mb-4">
          {page.title}
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-600 dark:text-gray-400">{page.subtitle}</p>
      </div>
      <div>
        {page.content}
      </div>
    </motion.div>
  );
}
