import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import Stripe from "stripe";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Stripe Checkout
  app.post("/api/create-checkout-session", async (req, res) => {
    try {
      const appUrl = process.env.APP_URL || `http://localhost:${PORT}`;
      const stripeKey = process.env.STRIPE_SECRET_KEY;
      
      if (!stripeKey) {
        // Fallback for users without a Stripe Key to simulate the experience
        console.warn("No STRIPE_SECRET_KEY found. Using mock checkout flow.");
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        return res.json({ url: `${appUrl}/?payment_success=true&simulated=true` });
      }

      const stripe = new Stripe(stripeKey);

      // Create a Stripe Checkout Session
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: "Nexus SaaS Pro Plan",
                description: "Enterprise-grade infrastructure for modern teams.",
              },
              unit_amount: 9900, // $99.00
            },
            quantity: 1,
          },
        ],
        mode: "payment",
        success_url: `${appUrl}/?payment_success=true`,
        cancel_url: `${appUrl}/?payment_canceled=true`,
      });

      res.json({ url: session.url });
    } catch (e: any) {
      console.error("Stripe error:", e);
      res.status(500).json({ error: e.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
